## Iron ThumbnailMaker


Run locally

~~~
docker run --rm -v "$(pwd)":/worker -w /worker iron/images:php-5.6 sh -c "php /worker/workers/ThumbMaker.php -payload payload.json"
~~~

Get into the bash

~~~
docker run -it -v "$(pwd)":/worker -w /worker iron/images:php-5.6 /bin/bash
~~~

Set your .env
