<?php # config/bugsnag.php

return array(
    'api_key' => env('BUG_SNAG')
);